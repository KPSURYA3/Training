public class Sum {
    public static int method(int num1, int num2)
    {
        return num1+num2;
    }
    
    public static void main(String[] args)
    {
        int res = Sum.method(28, 49);
        System.out.println(res);
    }
}
